#[macro_use]
extern crate glium;
extern crate cgmath;
use glium::Surface;
use glium::glutin;
use glium::index::PrimitiveType;
extern crate rand;
//use cgmath;
mod support;
use std::borrow::Cow;
use std::cell::RefCell;
use std::rc::Rc;
fn GetFaceTransform(i: i32) -> cgmath::Matrix3<f32>
{
    match i {
        0 =>
			return cgmath::Matrix3::<f32>::new(
				 0.0, 0.0, 1.0,
				 0.0, 1.0, 0.0,
				 1.0, 0.0, 0.0
			),
		1 =>
			return cgmath::Matrix3::<f32>::new(
				 0.0, 0.0,-1.0,
				 0.0, 1.0, 0.0,
				-1.0, 0.0, 0.0
			),
		2 =>
			return cgmath::Matrix3::<f32>::new(
				 1.0, 0.0, 0.0,
				 0.0, 0.0, 1.0,
				 0.0, 1.0, 0.0
			),
		3 =>
			return cgmath::Matrix3::<f32>::new(
				 1.0, 0.0, 0.0,
				 0.0, 0.0,-1.0,
				 0.0,-1.0, 0.0
			),
		4 =>
			return cgmath::Matrix3::<f32>::new(
				-1.0, 0.0, 0.0,
				 0.0, 1.0, 0.0,
				 0.0, 0.0, 1.0
			),
		5 =>{
        //println!("YAHOOOOOOOOOO" );
			return cgmath::Matrix3::<f32>::new(
				1.0, 0.0, 0.0,
				0.0, 1.0, 0.0,
				0.0, 0.0,-1.0
			)},
            _ => {
                println!("TEST" );
    			return cgmath::Matrix3::<f32>::new(
    				 1.0, 0.0, 0.0,
    				 0.0, 1.0, 0.0,
    				 0.0, 0.0, 1.0
    			)},

    }
}


mod fxaa {
    use glium::{self, Surface};
    use glium::backend::Facade;
    use glium::backend::Context;
    use glium::framebuffer::SimpleFrameBuffer;

    use std::cell::RefCell;
    use std::rc::Rc;
    use support::camera::CameraState;


    pub struct FxaaSystem {
        context: Rc<Context>,
        vertex_buffer: glium::VertexBuffer<SpriteVertex>,
        index_buffer: glium::IndexBuffer<u16>,
        program: glium::Program,
        target_color: RefCell<Option<glium::texture::Texture2d>>,
        target_depth: RefCell<Option<glium::framebuffer::DepthRenderBuffer>>,
        camera:  Rc<RefCell<CameraState>>

    }

    #[derive(Copy, Clone)]
    struct SpriteVertex {
        position: [f32; 2],
        i_tex_coords: [f32; 2],
    }

    implement_vertex!(SpriteVertex, position, i_tex_coords);

    impl FxaaSystem {
        pub fn new<F>(facade: &F, camera: Rc<RefCell<CameraState>>) -> FxaaSystem where F: Facade + Clone {
            FxaaSystem {
                context: facade.get_context().clone(),
camera:  camera.clone(),
                vertex_buffer: glium::VertexBuffer::new(facade,
                    &[
                        SpriteVertex { position: [-1.0, -1.0], i_tex_coords: [0.0, 0.0] },
                        SpriteVertex { position: [-1.0,  1.0], i_tex_coords: [0.0, 1.0] },
                        SpriteVertex { position: [ 1.0,  1.0], i_tex_coords: [1.0, 1.0] },
                        SpriteVertex { position: [ 1.0, -1.0], i_tex_coords: [1.0, 0.0] }
                    ]
                ).unwrap(),

                index_buffer: glium::index::IndexBuffer::new(facade,
                    glium::index::PrimitiveType::TriangleStrip, &[1 as u16, 2, 0, 3]).unwrap(),

                program: program!(facade,
                    100 => {
                        vertex: r"
                            #version 100

                            attribute vec2 position;
                            attribute vec2 i_tex_coords;

                            varying vec2 v_tex_coords;

                            void main() {
                                gl_Position = vec4(position, 0.0, 1.0);
                                v_tex_coords = i_tex_coords;
                            }
                        ",
                        fragment: r"

                        uniform vec3      iResolution;           // viewport resolution (in pixels)
                        uniform float     iGlobalTime;           // shader playback time (in seconds)
                        uniform float     iTimeDelta;            // render time (in seconds)
                        uniform int       iFrame;                // shader playback frame
                        uniform vec4      iDate;                 // (year, month, day, time in seconds)
                        uniform sampler2D tex;
                        uniform mat4      cam;
                        uniform mat4      trans;
                        uniform vec3      campos;

                        #define M_MAX 1e9
                        #define KEY_M (float(77)+0.5)/256.0

                        const float M_PI = 3.1415926535;
                        const float M_4PI = 4.0 * M_PI;

                        ///////////////////////////////////////
                        // planet
                        const float earthRadius 	= 1500.0-45-20.0;//6360.0;
                        const float atmoHeight 		= 100.0;
                        const float atmoRadius 		= earthRadius + atmoHeight;
                        const vec3 earthCenter 		= vec3(0.0, 0.0, 0.0);

                        ///////////////////////////////////////
                        // sun
                        const float distanceToSun = 1.496e8;
                        const float sunRadius = 2.0 * 109.0 * earthRadius;
                        const float sunIntensity = 10.0;

                        ///////////////////////////////////////
                        // atmosphere
                        const vec3 betaR 			= vec3(5.8e-4, 1.35e-3, 3.31e-3);
                        const vec3 betaM 			= vec3(4.0e-3, 4.0e-3, 4.0e-3);

                        const vec3 M_4PIbetaR	 	= M_4PI * betaR;
                        const vec3 M_4PIbetaM 		= M_4PI * betaM;

                        const float heightScaleRayleight = 6.0;
                        const float heightScaleMie = 1.2;
                        const float g = -0.76;

                        const float NUM_DENSITY_SAMPLES = 8.0;
                        const float NUM_VIEW_SAMPLES = 8.0;
                        const int 	INT_NUM_DENSITY_SAMPLES = int(NUM_DENSITY_SAMPLES);
                        const int	INT_NUM_VIEW_SAMPLES = int(NUM_VIEW_SAMPLES);

                        ///////////////////////////////////////
                        // ray - sphere intersection
                        vec2 iSphere(vec3 ro, vec3 rd, vec4 sph)
                        {
                            vec3 tmp = ro - sph.xyz;

                            float b = dot(rd, tmp);
                            float c = dot(tmp, tmp) - sph.w * sph.w;

                            float disc = (b * b - c);

                            if(disc < 0.0) return vec2(-M_MAX, -M_MAX);

                            float disc_sqrt = sqrt(disc);

                            float t0 = -b - disc_sqrt;
                            float t1 = -b + disc_sqrt;

                            return vec2(t0, t1);
                        }

                        ///////////////////////////////////////
                        // Henyey-Greenstein phase function
                        float phase(float nu, float g)
                        {
                        	return (3.0 * (1.0 - g * g) * (1.0 + nu * nu)) / (2.0 * (2.0 + g * g) * pow(1.0 + g * g - 2.0 * g * nu, 1.5));
                        }

                        ///////////////////////////////////////
                        // density integral calculation from p0 to p1
                        // for mie and rayleight
                        vec2 densityOverPath(vec3 p0, vec3 p1, vec2 prescaler)
                        {
                            float l = length(p1 - p0);
                            vec3  v = (p1 - p0) / l;

                            l /= NUM_DENSITY_SAMPLES;

                            vec2 density = vec2(0.0);
                            float t = 0.0;

                        	for(int i = 0; i < INT_NUM_DENSITY_SAMPLES; i++)
                            {
                                vec3 sp = p0 + v * (t + 0.5 * l);
                                vec2 h = vec2(length(sp) - earthRadius);
                                density += exp(-h / prescaler);

                                t += l;
                            }

                            return l * density;
                        }

                        ///////////////////////////////////////
                        // inscatter integral calculation
                        vec4 inscatter(vec3 cam, vec3 v, vec3 sun)
                        {
                            vec4 atmoSphere 	= vec4(earthCenter, atmoRadius);
                            vec4 earthSphere 	= vec4(earthCenter, earthRadius);

                        	vec2 t0 = iSphere(cam, v, atmoSphere);
                            vec2 t1 = iSphere(cam, v, earthSphere);

                            bool bNoPlanetIntersection = t1.x < 0.0 && t1.y < 0.0;

                            float farPoint = bNoPlanetIntersection ? t0.y : t1.x;
                            float nearPoint = t0.x > 0.0 ? t0.x : 0.0;

                            float l = (farPoint - nearPoint) / NUM_VIEW_SAMPLES;
                        	cam += nearPoint * v;

                            float t = 0.0;

                            vec3 rayleight = vec3(0.0);
                        	vec3 mie = vec3(0.0);

                            vec2 prescalers = vec2(heightScaleRayleight, heightScaleMie);

                            vec2 densityPointToCam = vec2(0.0);

                            for(int i = 0; i < INT_NUM_VIEW_SAMPLES; i++)
                            {
                                vec3 sp = cam + v * (t + 0.5 * l);
                                float tc = iSphere(sp, sun, vec4(earthCenter, atmoRadius)).y;

                                vec3 pc = sp + tc * sun;

                                vec2 densitySPCam = densityOverPath(sp, cam, prescalers);
                                vec2 densities = densityOverPath(sp, pc, prescalers) + densitySPCam;

                                vec2 h = vec2(length(sp) - earthRadius);
                                vec2 expRM = exp(-h / prescalers);

                                rayleight 	+= expRM.x * exp( -M_4PIbetaR * densities.x );
                        		mie 		+= expRM.y * exp( -M_4PIbetaM * densities.y );

                        		densityPointToCam += densitySPCam;

                                t += l;
                            }

                        	rayleight *= l;
                            mie *= l;

                            vec3 extinction = exp( - (M_4PIbetaR * densityPointToCam.x + M_4PIbetaM * densityPointToCam.y));

                            float nu = dot(sun, -v);

                            vec3 inscatter_ = sunIntensity * (betaM * mie * phase(nu, g) + betaR * phase(nu, 0.0) * rayleight);
                            return vec4(inscatter_, extinction.r * float(bNoPlanetIntersection));
                        }

                        ///////////////////////////////////////
                        // rotation around axis Y
                        vec3 rotate_y(vec3 v, float angle)
                        {
                        	vec3 vo = v; float cosa = cos(angle); float sina = sin(angle);
                        	v.x = cosa*vo.x - sina*vo.z;
                        	v.z = sina*vo.x + cosa*vo.z;
                        	return v;
                        }

                        ///////////////////////////////////////
                        // noise from iq
                        float noise( in vec3 x )
                        {
                            vec3 p = floor(x);
                            vec3 f = fract(x);
                        	f = f*f*(3.0-2.0*f);

                        	vec2 uv = (p.xy+vec2(37.0,17.0) * p.z) + f.xy;
                        	vec2 rg = vec2(0.0);//texture2D( iChannel0, (uv + 0.5)/256.0, -100.0 ).yx;
                        	return mix( rg.x, rg.y, f.z );
                        }


                        in vec2 v_tex_coords;
                        out vec4 fragColor;;

                        vec4 blend(vec4 result, vec4 rhs) {
                            float a = result.w + rhs.w;
                            if (a > 1.0) a = 1.0;
                            float r = (result.x * (1.0 * rhs.w)) + (rhs.x * rhs.w);
                            float g = (result.y * (1.0 * rhs.w)) + (rhs.y * rhs.w);
                            float b = (result.z * (1.0 * rhs.w)) + (rhs.z * rhs.w);

                            return vec4(r, g, b, a);
                        }

                        void main(   )
                        {
                            vec2 sc = 2.0 * v_tex_coords.xy ;/// iResolution.xy - 1.0;
                            sc.x *= iResolution.x / iResolution.y;
                            sc.x -= iResolution.x / iResolution.y;
                            sc.y *= iResolution.y / iResolution.x;

                            sc.y -= (iResolution.y/ iResolution.x);

                  vec3 mouse = 4.0 * vec3(2.0 * vec2(0.5,0.5).xy / iResolution.xy - 1.0,0.0);

                  vec3 ro = vec3(0.0);

                  bool key_m = true;//texture2D(iChannel1, vec2(KEY_M, 0.75)).x > 0.0;
                 	//ro = 2.0 * vec3(0, 0.0, earthRadius );

                  //ro = mat3(camtrans)*(1.0*vec3(campos));
                  //ro =((0.1+(6.0*length(campos)/(earthRadius)))*vec3(campos));
                  //ro =(6.200*(200.0+earthRadius-length(campos))/(earthRadius))*( mat3(trans*cam)*normalize(campos));
                 /// ro =(M_PI/4.0) *campos;
                  ro =(M_PI/3.61) * mat3(cam) * campos;
                  vec3 rd = normalize(rotate_y(vec3(sc, 1.2), M_PI - 0.0));
                  rd =  normalize(mat3(cam)*vec3(sc,-1.0));
                  vec3 sun = normalize(vec3(1.0, 1.0, 1.0));

                  vec4 col = inscatter(ro, rd, sun);

                  vec3 sunPos = sun * distanceToSun;

                  vec4 star = vec4(sunPos, sunRadius);
                  vec2 t0 = iSphere(ro, rd, star);

                  if(t0.x > 0.0)
                  {
                  	col.xyz += vec3(1.0,1.0,1.0) * col.a;
                  }
                  //col.xyz = col.xyz + stars * col.a;
                  col.xyz = pow(col.xyz, vec3(1.0 / 2.2));

                  //fragColor = col;
                  vec4 bbb = texture2D(tex,v_tex_coords);
                  //fragColor = col*0.5;
                  //fragColor +=col* bbb;
                 // fragColor =clamp(col, 0.0, 1.0)+ clamp(bbb, 0.0, 1.0);
                // fragColor =blend(col,bbb);
                fragColor =(col+bbb);
                        }                        "
                    }
                ).unwrap(),

                target_color: RefCell::new(None),
                target_depth: RefCell::new(None),
            }
        }
    }

    pub fn draw<T, F, R>(system: &FxaaSystem, target: &mut T, enabled: bool, mut draw: F)
                         -> R where T: Surface, F: FnMut(&mut SimpleFrameBuffer) -> R
    {
        let target_dimensions = target.get_dimensions();

        let mut target_color = system.target_color.borrow_mut();
        let mut target_depth = system.target_depth.borrow_mut();

        {
            let clear = if let &Some(ref tex) = &*target_color {
                tex.get_width() != target_dimensions.0 ||
                    tex.get_height().unwrap() != target_dimensions.1
            } else {
                false
            };
            if clear { *target_color = None; }
        }

        {
            let clear = if let &Some(ref tex) = &*target_depth {
                tex.get_dimensions() != target_dimensions
            } else {
                false
            };
            if clear { *target_depth = None; }
        }

        if target_color.is_none() {
            let texture = glium::texture::Texture2d::empty(&system.context,
                                                           target_dimensions.0 as u32,
                                                           target_dimensions.1 as u32).unwrap();
            *target_color = Some(texture);
        }
        let target_color = target_color.as_ref().unwrap();

        if target_depth.is_none() {
            let texture = glium::framebuffer::DepthRenderBuffer::new(&system.context,
                                                                      glium::texture::DepthFormat::I24,
                                                                      target_dimensions.0 as u32,
                                                                      target_dimensions.1 as u32).unwrap();
            *target_depth = Some(texture);
        }
        let target_depth = target_depth.as_ref().unwrap();

        let output = draw(&mut SimpleFrameBuffer::with_depth_buffer(&system.context, target_color,
                                                                                     target_depth).unwrap());

        let uniforms = uniform! {
            tex: &*target_color,
            enabled: if enabled { 1i32 } else { 1i32 },
            resolution: (target_dimensions.0 as f32, target_dimensions.1 as f32),
            iResolution: (target_dimensions.0 as f32, target_dimensions.1 as f32 , 1f32),           // viewport resolution (in pixels)
            iGlobalTime: 0.0f32,           // shader playback time (in seconds)
            iTimeDelta: 1f32,            // render time (in seconds)
            iFrameL: 1,                // shader playback frame
            iDate: (2016,07,18,5466),                 // (year, month, day, time in seconds)
            cam: system.camera.borrow_mut().get_perspective(),
            trans: system.camera.borrow_mut().get_view(),
            campos: system.camera.borrow_mut().get_position(),

        };

        target.draw(&system.vertex_buffer, &system.index_buffer, &system.program, &uniforms,
                    &Default::default()).unwrap();

        output
    }
}


fn main() {

    use glium::DisplayBuild;
let m_size  = 128;
    // building the display, ie. the main object
    let display = glutin::WindowBuilder::new()
        .with_depth_buffer(24)
        .build_glium()
        .unwrap();

        let mut vertice_buffers = Vec::new();
        let mut index_buffers = Vec::new();

        #[derive(Copy, Clone)]
        struct Vertex {
            position: [f32; 4],
        }

        implement_vertex!(Vertex,position);



        for idx in 0..6 {
                let mut vertices = Vec::new();
        		vertices.resize(m_size*m_size, cgmath::Vector4::new(0f32,0f32,0f32,1f32));
                let mut vertices2 = Vec::new();
        		vertices2.resize(m_size*m_size, Vertex{position:[0f32,0f32,0f32,1f32]});

                let offsetX : f32 = 1.0 / (m_size-1) as f32;
        		let offsetZ = 1.0 / (m_size-1) as f32;
        		for z in 0..m_size
                {
                    for x in 0..m_size
            		{
            			vertices[x + z*m_size].x = x as f32 * offsetX ;
            			vertices[x + z*m_size].y = z as f32*offsetZ ;
            			vertices[x + z*m_size].z = 0.0;
            			vertices[x + z*m_size].w = 1.0;
            	    }
                }



                for mut z in 0..(m_size*m_size)
                {

                    vertices2[z] = (Vertex { position: [vertices[z].x,vertices[z].y,vertices[z].z,vertices[z].w] });
                //    println!("{:?}", vertices2[z].vs_Position);
            //
//            vertices2[z] = (Vertex { position: [100.0*rand::random::<f32>(),100.0*rand::random::<f32>(),100.0*rand::random::<f32>()] });
        //
                }

            let mut indices = Vec::new();
    		indices.resize((m_size-1)*(m_size-1) * 4, 0u16);
            for z in 0..m_size-1
            {
                for x in 0..m_size-1
                {
        			let offset = (x+z * (m_size-1)) * 4;
        			let p1 : u16 = (x + z*m_size) as u16;
        			let p2 : u16 = (p1 as usize + m_size) as u16;
        			let p3 : u16 = (p2 + 1) as u16;
        			let p4 : u16 = (p1 + 1) as u16;

        			indices[offset + 0] = p1;
        			indices[offset + 1] = p2;
        			indices[offset + 2] = p3;
        			indices[offset + 3] = p4;
        		}
                //                vertices2[z] = (Vertex { position: [100.0*rand::random::<f32>(),100.0*rand::random::<f32>(),100.0*rand::random::<f32>(),vertices[z].w] });
            }






            let vertex_buffer = glium::VertexBuffer::new(&display, &vertices2).unwrap();


        vertice_buffers.push(vertex_buffer);

        // building the index buffer
        let index_buffer = glium::index::IndexBuffer::new(&display,
                                                    //PrimitiveType::Points,
                                                   PrimitiveType::Patches { vertices_per_patch: 4 },
                                                   &indices).unwrap();

                                                           index_buffers.push(index_buffer);

        }



    // the program
    let program = glium::Program::new(&display,
        glium::program::SourceCode  {
            vertex_shader: "
                #version 400

                uniform mat4 u_ModelViewProj;
                uniform mat4 uP;
                uniform vec3 u_CamPosition;


                uniform float u_Radius;
                uniform float u_Height;

                uniform vec3 u_FaceTransform1;
                uniform vec3 u_FaceTransform2;
                uniform vec3 u_FaceTransform3;

                layout(location = 0) in vec4 position;
                out vec4 tcs_WorldPos;
                out vec2 tcs_TexCoord;
                out vec3 normal;


                vec3 spherical(vec2 uv, float h) {
                	mat3 t = mat3(u_FaceTransform1, u_FaceTransform2, u_FaceTransform3);
                	return normalize(t * vec3(uv, 1)) * (u_Radius + h * u_Height);
                }

                void main() {
                	vec2 uv = vec2(position.xy) * vec2(2) + vec2(-1);
                	float h = 1.0;
                	tcs_WorldPos = vec4(spherical(uv, h), 1);
                	tcs_TexCoord = position.xy;
                    //normal = normalize(gl_NormalMatrix * gl_Normal);
                    //gl_Position = u_ModelViewProj * uP * tcs_WorldPos * 1000.0;
                }
            ",

            tessellation_control_shader: Some("
#version 400
uniform float u_LODFactor;
uniform vec3 u_CamPosition;
uniform mat4 u_ModelViewProj;
uniform mat4 uP;

uniform float u_Radius;
uniform float u_Height;

uniform vec3 u_FaceTransform1;
uniform vec3 u_FaceTransform2;
uniform vec3 u_FaceTransform3;



layout(vertices = 4) out;
in vec4 tcs_WorldPos[];
in vec2 tcs_TexCoord[];
out vec2 tes_TexCoord[];

vec3 spherical(vec2 uv, float h) {
	mat3 t = mat3(u_FaceTransform1, u_FaceTransform2, u_FaceTransform3);
	return normalize(t * vec3(uv, 1)) * (u_Radius + h * u_Height);
}


vec4 project(vec4 pos) {
	vec4 result = u_ModelViewProj * uP * pos;
	result /= result.w;
	return result;
}

bool offscreen(vec4 pos) {
	//return any(lessThan(pos.xy, vec2(-1.7)) || greaterThan(pos.xy, vec2(1.7)));

    return any(lessThan(pos.xy, vec2(-500)) || greaterThan(pos.xy, vec2(500)));
}

float level_ORIGIINAL(float d) {
	return clamp(u_LODFactor*2000/(d), 1, 64);
}

float level(float d, float camheight) {
	return clamp((u_LODFactor+(0.25*(2.0-min(camheight/1580.0, 2.0))))*2000/d, 1, 64);
}
void main() {
	#define ID gl_InvocationID
	if(ID == 0)
	{
		vec4 v0 = project(tcs_WorldPos[0]);
		vec4 v1 = project(tcs_WorldPos[1]);
		vec4 v2 = project(tcs_WorldPos[2]);
		vec4 v3 = project(tcs_WorldPos[3]);


		if(all(bvec4(offscreen(v0),offscreen(v1), offscreen(v2),offscreen(v3))))
		{
			gl_TessLevelOuter[0] = 0;
			gl_TessLevelOuter[1] = 0;
			gl_TessLevelOuter[2] = 0;
			gl_TessLevelOuter[3] = 0;

			gl_TessLevelInner[0] = 0;
			gl_TessLevelInner[1] = 0;
		}
		else
		{
			float d0 = distance(u_CamPosition, tcs_WorldPos[0].xyz);
			float d1 = distance(u_CamPosition, tcs_WorldPos[1].xyz);
			float d2 = distance(u_CamPosition, tcs_WorldPos[2].xyz);
			float d3 = distance(u_CamPosition, tcs_WorldPos[3].xyz);
            float h = length(u_CamPosition);
			gl_TessLevelOuter[0] = level(mix(d3, d0, .5), h);
			gl_TessLevelOuter[1] = level(mix(d0, d1, .5), h);
			gl_TessLevelOuter[2] = level(mix(d1, d2, .5), h);
			gl_TessLevelOuter[3] = level(mix(d2, d3, .5), h);

			float l = max(max(gl_TessLevelOuter[0], gl_TessLevelOuter[1]), max(gl_TessLevelOuter[2], gl_TessLevelOuter[3]));
			gl_TessLevelInner[0] = l;
			gl_TessLevelInner[1] = l;
		}
	}

	tes_TexCoord[ID] = tcs_TexCoord[ID];
}")
,

            tessellation_evaluation_shader: Some("
#version 400
layout(quads, fractional_odd_spacing, ccw) in;
//layout(quads, equal_spacing, ccw) in;
in vec2 tes_TexCoord[];
out float fs_Height;
out vec3 fs_Normal;

uniform vec3 u_CamPosition;
uniform mat4 u_ModelViewProj;
uniform mat4 uP;

uniform float u_Radius;
uniform float u_Height;

uniform vec3 u_FaceTransform1;
uniform vec3 u_FaceTransform2;
uniform vec3 u_FaceTransform3;


vec3 spherical(vec2 uv, float h) {
	mat3 t = mat3(u_FaceTransform1, u_FaceTransform2, u_FaceTransform3);
	return normalize(t * vec3(uv, 1)) * (u_Radius + h * u_Height);
}


vec2 interpolate(vec2 bl, vec2 br, vec2 tr, vec2 tl)
{
	float u = gl_TessCoord.x;
	float v = gl_TessCoord.y;

	vec2 b = mix(bl,br,u);
	vec2 t = mix(tl,tr,u);
	return mix(b,t,v);
}

//--

//--
vec4 permute(vec4 x) {
	x+=34*x*x;
	return x-floor(x/289.)*289.;
}

float snoise(vec3 v)
{
  vec2  C = vec2(1.0/6.0, 1.0/3.0) ;
  vec4  D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy) );
  vec3 x0 =   v - i + dot(i, C.xxx) ;

  vec3 g = step(x0.yzx, x0);
  vec3 l = 1.0 - g;
  vec3 i1 = min( g, l.zxy );
  vec3 i2 = max( g, l.zxy );


  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy; // 2.0*C.x = 1/3 = C.y
  vec3 x3 = x0 - D.yyy;      // -1.0+3.0*C.x = -0.5 = -D.y


  i -= floor(i / 289.) * 289.;
  vec4 p = permute( permute( permute(
             i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0 ))
           + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));


  vec3  ns = D.wyz/7. - D.xzx;

  vec4 j = p - 49. * floor(p * ns.z * ns.z);  //  mod(p,7*7)

  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7. * x_ );    // mod(j,N)

  vec4 x = x_ *ns.x + ns.yyyy;
  vec4 y = y_ *ns.x + ns.yyyy;
  vec4 h = 1. - abs(x) - abs(y);

  vec4 b0 = vec4( x.xy, y.xy );
  vec4 b1 = vec4( x.zw, y.zw );

  //vec4 s0 = vec4(lessThan(b0,0.0))*2.0 - 1.0;
  //vec4 s1 = vec4(lessThan(b1,0.0))*2.0 - 1.0;
  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0,0,0,0));

  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy ;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww ;

  vec3 p0 = normalize(vec3(a0.xy,h.x));
  vec3 p1 = normalize(vec3(a0.zw,h.y));
  vec3 p2 = normalize(vec3(a1.xy,h.z));
  vec3 p3 = normalize(vec3(a1.zw,h.w));

// Mix final noise value
  vec4 m = max(.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  return 42.0 * dot( m*m*m*m, vec4( dot(p0,x0), dot(p1,x1),
                                dot(p2,x2), dot(p3,x3) ) );
}

///

float ph(vec3 rpos)
{
//	return snoise(rpos);
//	return fInnerRadius*(clamp(snoise(rpos*16)+snoise(rpos*256)/5)/200+1, 0.0, 1.0);
	float desert=clamp(abs(rpos.y)*5, 0.0, 1.0);

	float gain=desert*.2+.2;//lerp(.2, .4/*mountain_params.x*/, desert);//0.4;
	float max_height=desert*.008+.002;//lerp(.002, .01, desert);//;//lerp(0.002, planet_params.x, desert);//0.01;
	//float plains=0.5;//mountain_params.y;//0.5;

	float sum=0;
	float amplitude=.5;
	float prev=1;

	float fbm_sum=0;
	float fbm_amp=.5;//0.5;

	prev=min(abs(snoise(rpos*4)*4), 1);

//	float time=(float)ct1/44100.0+80;
//	time=smoothstep(85,120,time);
	float time=0;//smoothstep(3748500,5292000,ct1);//+3528000);
	float lacunarity=2.7-time;//(roughnoise*.05+1)*2.7; // lacunarity=2.7
	rpos*=lacunarity;
	for (uint i=0;i<2;i++)
	{
		float noise_sample=snoise(rpos);
		rpos*=lacunarity;
		fbm_sum+=noise_sample*pow(fbm_amp, -.8); // fbm_gain=0.8
		fbm_amp*=lacunarity;
	}

	float continent=fbm_sum;
//	float noise_sample;
	for (uint i=0;i<8;i++)
	{
		float noise_sample=snoise(rpos);

		float n=pow(1-abs(noise_sample),2);//ridge(noise_sample, offset);
		sum+=n*amplitude*prev;
		prev=n;
		rpos*=lacunarity;
		amplitude*=gain;

		if (i==0)
			gain*=pow(prev, .5);//plains);


		fbm_sum+=noise_sample*pow(fbm_amp, -.8); // fbm_gain=0.8
		fbm_amp*=lacunarity;
	}

	sum=sum*sum;
//	fbm_sum=min((fbm_sum+time*8)*8, 1); // fbm_shores=8.0
	fbm_sum=min(fbm_sum*8+time*128, 1); // fbm_shores=8.0
	sum+=max(continent/2, 0);
	sum*=fbm_sum;

	sum=0.8*mix(sum,-.001,clamp(sum*-150+1, 0.0, 1.0)); //AHMED

    return sum;
//	return fInnerRadius*(sum*max_height+1);
}


void main() {
	vec2 coord = interpolate(tes_TexCoord[0], tes_TexCoord[1], tes_TexCoord[2], tes_TexCoord[3]);
	vec2 uv = vec2(coord.xy) * vec2(2) + vec2(-1);

    float MAG = 1.0;

//	float NORMAL_OFF = (1.0 / 8.0);
//vec3 off = vec3(-NORMAL_OFF, 0, NORMAL_OFF);
	// s11 = Current

//float s11 = ((((perlin(coord)))*MAG));

// s01 = Left
//float s01 = ((((perlin(coord+off.xy)))*MAG));

// s21 = Right
//float s21 = ((((perlin(coord+off.zy)))*MAG));

// s10 = Below
//float s10 = ((((perlin(coord+off.yx)))*MAG));

// s12 = Above
//float s12 = ((((snoise(coord+off.yz)))*MAG));

//vec3 va = normalize( vec3(off.z, 0.0, s21 - s11) );
//vec3 vb = normalize( vec3(0.0, off.z, s12 - s11) );

//vec3 normal = normalize( cross(va, vb) );
//fs_Normal =   normalize( cross(va, vb) );

/*
fs_Height =  ((0.5*(noise(coord*1000.0, 200))+(1.0*noise(coord*15.0, 200)))*MAG);
fs_Height = max(fs_Height, 0.6);
	vec4 spos = vec4(spherical(uv,fs_Height), 1);
*/
float hhh = clamp(ph(spherical(uv,0.1)*0.0005)*0.9+(snoise(spherical(uv,0.1)*0.001)+0.1)*0.65+(snoise(spherical(uv,0.1)*0.06))*0.009, 0 , 1);

fs_Height = hhh;
gl_Position = u_ModelViewProj * uP * vec4(spherical(uv,hhh*0.7), 1.0);
}
"),

geometry_shader: None,
/*
Some("
#version 330

uniform mat4 matrix;

layout(triangles) in;
layout(triangle_strip, max_vertices=3) out;

in vec3 fs_Normal;
out vec3 color;
in vec3[] normal;
out vec3 normal2;

float rand(vec2 co) {
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

void main() {


    gl_Position = gl_in[0].gl_Position;

    //vec3 normal = normalize( cross(va, vb) );
    //fs_Normal = normal;
    normal2 = fs_Normal;//normalize(cross(gl_in[0].gl_Position.xyz - gl_in[2].gl_Position.xyz, gl_in[1].gl_Position.xyz-gl_in[2].gl_Position.xyz));
    EmitVertex();

    gl_Position = gl_in[1].gl_Position;
    normal2 = fs_Normal;//normalize(cross(gl_in[1].gl_Position.xyz - gl_in[0].gl_Position.xyz, gl_in[2].gl_Position.xyz-gl_in[0].gl_Position.xyz));
    EmitVertex();

    gl_Position =  gl_in[2].gl_Position;
    normal2 = fs_Normal;//normalize(cross(gl_in[2].gl_Position.xyz - gl_in[1].gl_Position.xyz, gl_in[0].gl_Position.xyz-gl_in[1].gl_Position.xyz));
    EmitVertex();
}
"),*/

            fragment_shader: ("
            in float fs_Height;
            in vec3 fs_Normal;
            varying in vec3 normal2;
            out vec4 frag;
            uniform vec3 u_CamPosition;

            void main() {

                  vec3 E = normalize(-u_CamPosition); // we are in Eye Coordinates, so EyePos is (0,0,0)
                  vec3 R = normalize(reflect(-normalize(vec3(1,0.5,5.5)),fs_Normal));

                  //calculate Ambient Term:
                  vec4 Iamb =vec4(0.01,0.01,0.03,1.0);

                  //calculate Diffuse Term:
                  vec4 zxc = vec4(0.0,0.4,0.0,1.0)*fs_Height;
                  if (fs_Height > 0.5)
                      zxc = mix(zxc,vec4(1.0,1.0,1.0,1.0), (fs_Height-0.5)*2.0);
                  if (fs_Height < 0.001)
                    zxc = mix(zxc,vec4(0.0,0.0,0.75,1.0), (fs_Height+0.001)*(fs_Height/0.001));

//                      zxc = vec4(0.0,0.0,0.75,1.0);
                  vec4 Idiff = 1*zxc;// * max(dot(fs_Normal,normalize(vec3(1,0.5,5.5))), 0.0);
                  Idiff = clamp(Idiff, 0.0, 1.0);

                  // calculate Specular Term:
                  vec4 Ispec = vec4(0.2,0.2,0.2,1.0)
                               * pow(max(dot(R,E),0.0),0.3*0.3);
                  Ispec = clamp(Ispec, 0.0, 1.0);
                  // write Total Color:
                    frag = Iamb + Idiff;// + Ispec;
}
            ")
        },
    ).unwrap();



    //
    let mut  camera = Rc::new(RefCell::new(support::camera::CameraState::new()));//.clone();
camera.borrow_mut().set_position((-00f32,-0f32, 3300.0-00.0f32));
    let fxaa = fxaa::FxaaSystem::new(&display,camera.clone());
    let mut fxaa_enabled = true;

// the main loop
    support::start_loop(|| {
        camera.borrow_mut().update();

        // building the uniforms
        let mut uniforms  = Vec::new();

        for idx in 0..6 {
        uniforms.push(
        uniform! {
            u_ModelViewProj: camera.borrow_mut().get_perspective(),
            uP: camera.borrow_mut().get_view(),
            view_matrix: camera.borrow_mut().get_view(),
            persp_matrix: camera.borrow_mut().get_perspective(),
            u_CamPosition: camera.borrow_mut().get_position(),
            u_LODFactor: 0.35f32,
            u_Radius: 1500.0f32,
            u_Height: 80.0f32,
            u_FaceTransform1: (GetFaceTransform(idx).x.x, GetFaceTransform(idx).y.x, GetFaceTransform(idx).z.x),
            u_FaceTransform2: (GetFaceTransform(idx).x.y, GetFaceTransform(idx).y.y, GetFaceTransform(idx).z.y),
            u_FaceTransform3: (GetFaceTransform(idx).x.z, GetFaceTransform(idx).y.z, GetFaceTransform(idx).z.z)


        });
}




        // draw parameters
        let params = glium::DrawParameters {
            depth: glium::Depth {
                test: glium::DepthTest::IfLess,
                write: true,
                .. Default::default()
            },
            backface_culling: glium::draw_parameters::BackfaceCullingMode::CullClockwise,
            .. Default::default()
        };

        // drawing a frame
        let mut target = display.draw();

        fxaa::draw(&fxaa, &mut target, fxaa_enabled, |target| {
           //target.clear_color_and_depth((0.0, 0.0, 0.0, 0.0), 1.0);
           target.clear_color_and_depth((0.0, 0.0, 0.0, 0.0), 1.0);


           for idx in 0..6 {
           target.draw((&vertice_buffers[idx]),
                       //&glium::index::NoIndices(glium::index::PrimitiveType::Patches { vertices_per_patch: 4 }),
                       &index_buffers[idx],
                       &program, &uniforms[idx], &params);//&Default::default()).unwrap();

           }
        });


//        target.draw((&vbuffer),
//                    &ibuffer,
//                    &program2, &uniforms[0], &Default::default()).unwrap();


/*                            target.draw(&vertex_buffer2,
                                        &glium::index::NoIndices(glium::index::PrimitiveType::Points),
                                        &program2, &uniforms2, &params).unwrap();
*/
        target.finish().unwrap();

        // polling and handling the events received by the window
        for event in display.poll_events() {
            match event {
                glutin::Event::Closed => return support::Action::Stop,
                ev =>  camera.borrow_mut().process_input(&ev),
            }
        }

        support::Action::Continue
    });
}
